# sprinkle
뿌리기(sprinkle)

활용 dependency
* 언어 : Java
* Spring-flux, jpa, h2, lombok

핵심 문제해결 전략
* 테이블은 3개로 구성
  * 뿌리기 등록 테이블(sprinkle_submit)
  * 뿌린 돈을 나누어 저장한 테이블(sprinkle_divide)
  * 방에 존재하는 사용자인지 체크하는 테이블((sprinkle_room_user)  
* 받기 부분
  * submit 테이블과 divide 테이블을 동시 수정을 위해 트랜잭션으로 묶어야 함
  * 단일 서버면 자바단에서 락처리를 통해 처리 할 수 있지만, 여러 서버라는 가정이기 때문에 select for update를 통해 '받기'를 수행하는데 문제가 없도록 처리

API 3개
* 뿌리기 등록(Submit)
  * POST /sprinkle
  * Header(X_USER_ID, X_ROOM_ID), Body(sprinkleMoney, sprinkleManCnt)
* 뿌리기 받기(Consume)
  * POST /sprinkle/{token}
  * Header(X_USER_ID)
  * 받을 ROOM_ID 넘겨받는다는 내용이 없어서 ROOM_ID는 넘어오지 않는다는 가정, 대신 받을 사용자가 방에 있는 사용자인지 체크 필요
* 뿌리기 조회(Info)
  * GET /sprinkle/{token}
  * Header(X_USER_ID)
