package com.meteor.sprinkle;

public class SprinkleConst {
    public static final String sprinkle_CONST = "sprinkle";
    public static final String TOKEN_CONST = "token";
    public static final String X_USER_ID = "X-USER-ID";
    public static final String X_ROOM_ID = "X-ROOM-ID";
    public static final String TOKEN_URL = "/{" + TOKEN_CONST + "}";
    public static final String REQUEST_HEADER_INVALID = "RequestHeader Invalid";
    public static final String SPRINKLE_EMPTY_ERROR = "남은 뿌리기가 없습니다.";
    public static final String SPRINKLE_OWNER_CONSUME_FAIL = "본인이 발행한 뿌리기에는 참여 할 수 없습니다.";
    public static final String SPRINKLE_DUPLE_CONSUME_FAIL = "뿌리기는 한번만 받을 수 있습니다.";
    public static final String SPRINKLE_EXPIRED_DATE_ERROR = "뿌리기가 만료시간을 초과했습니다.";
    public static final String SPRINKLE_TOKEN_ID_GEN_FAIL = "토큰 생성에 실패했습니다.";
    public static final String SPRINKLE_ROOM_NEED_3MORE = "뿌리기 할 방에는 3명 이상 필요합니다.";
    public static final String SPRINKLE_MORE_MONEY_MAN_CNT = "인원수 보다 많은 금액이 필요합니다.";
    public static final String SPRINKLE_INVALID_MATCH = "일치하는 정보가 없습니다.";
    public static final String SPRINKLE_INFO_EXPIRED_DATE_ERROR = "뿌리기 조회 시간을 초과했습니다.";
}