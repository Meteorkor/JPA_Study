package com.meteor.sprinkle;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SprinkleMoneyApplication {

	public static void main(String[] args) {
		SpringApplication.run(SprinkleMoneyApplication.class, args);
	}

}
