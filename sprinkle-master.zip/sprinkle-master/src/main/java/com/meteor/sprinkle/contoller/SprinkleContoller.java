package com.meteor.sprinkle.contoller;

import com.meteor.sprinkle.SprinkleConst;
import com.meteor.sprinkle.dto.ResponseDTO;
import com.meteor.sprinkle.dto.SprinkleConsumerDTO;
import com.meteor.sprinkle.dto.SprinkleInfoDTO;
import com.meteor.sprinkle.dto.SprinkleSubmitRequestDTO;
import com.meteor.sprinkle.dto.SprinkleSubmitResponseDTO;
import com.meteor.sprinkle.exception.SprinkleException;
import com.meteor.sprinkle.service.SprinkleService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import reactor.core.publisher.Mono;
import reactor.core.scheduler.Schedulers;

import static com.meteor.sprinkle.SprinkleConst.REQUEST_HEADER_INVALID;
import static com.meteor.sprinkle.SprinkleConst.TOKEN_URL;
import static com.meteor.sprinkle.SprinkleConst.X_ROOM_ID;
import static com.meteor.sprinkle.SprinkleConst.X_USER_ID;

@RequestMapping(SprinkleConst.sprinkle_CONST)
@RestController
@RequiredArgsConstructor
@Slf4j
public class SprinkleContoller {
    private final SprinkleService sprinkleService;

    /**
     * 뿌리기 접수<br>
     *
     * @param sprinkleSubmitRequestDTO, 뿌릴 금액, 뿌릴 인원
     * @return SprinkleSubmitResponseDTO, token 반환
     */
    @PostMapping
    public Mono<ResponseEntity<ResponseDTO<SprinkleSubmitResponseDTO>>> sprinkleSubmit(@RequestBody SprinkleSubmitRequestDTO sprinkleSubmitRequestDTO, @RequestHeader(value = X_USER_ID, required = false) String userId, @RequestHeader(value = X_ROOM_ID, required = false) String roomId) {
        long sprinkleMoney = sprinkleSubmitRequestDTO.getSprinkleMoney();
        int sprinkleManCnt = sprinkleSubmitRequestDTO.getSprinkleManCnt();
        ResponseDTO<SprinkleSubmitResponseDTO> responseDto = new ResponseDTO<>();
        SprinkleSubmitResponseDTO dto = new SprinkleSubmitResponseDTO();
        dto.setRoomId(roomId);
        dto.setUserId(userId);
        responseDto.setData(dto);

        if (StringUtils.isEmpty(userId) || StringUtils.isEmpty(roomId)) {
            responseDto.setErrMsg(REQUEST_HEADER_INVALID);
            return Mono.just(ResponseEntity.badRequest().body(responseDto));
        }

        //인원수보다 많은 금액이여야 함
        if (sprinkleMoney < sprinkleManCnt) {
            responseDto.setErrMsg(SprinkleConst.SPRINKLE_MORE_MONEY_MAN_CNT);
            return Mono.just(ResponseEntity.badRequest().body(responseDto));
        }

        return Mono.defer(() -> {
            try {
                String tokenId = sprinkleService.createSprinkle(userId, roomId, sprinkleMoney, sprinkleManCnt);
                dto.setToken(tokenId);
                responseDto.setData(dto);
                responseDto.setDataCnt(1);
                return Mono.just(ResponseEntity.ok(responseDto));
            } catch (SprinkleException e) {
                log.error("sprinkle error", e);
                responseDto.setErrMsg(e.getMessage());
                return Mono.just(ResponseEntity.badRequest().body(responseDto));
            }
        }).subscribeOn(Schedulers.elastic());
    }


    /**
     * 뿌리기 받기<br>
     *
     * @param token, userId
     * @return SprinkleConsumerDTO, 본인이 받는 금액 반환
     */
    @PostMapping(TOKEN_URL)
    public Mono<ResponseEntity<ResponseDTO<SprinkleConsumerDTO>>> sprinkleConsume(@PathVariable("token") String token, @RequestHeader(X_USER_ID) String userId) {
        ResponseDTO<SprinkleConsumerDTO> responseDTO = new ResponseDTO<>();

        if (StringUtils.isEmpty(userId)) {
            responseDTO.setErrMsg(REQUEST_HEADER_INVALID);
            return Mono.just(ResponseEntity.badRequest().body(responseDTO));
        }
        return Mono.defer(() -> {
            try {
                responseDTO.setData(sprinkleService.consume(token, userId));
                responseDTO.setDataCnt(1);
            } catch (SprinkleException sprinkleException) {
                log.error("sprinkle error", sprinkleException);
                responseDTO.setErrMsg(sprinkleException.getMessage());
                return Mono.just(ResponseEntity.badRequest().body(responseDTO));
            }
            return Mono.just(ResponseEntity.ok(responseDTO));
        });
    }

    /**
     * 뿌리기 정보 조회<br>
     *
     * @param token,  발급 받은 토큰
     * @param userId, 자신만이 조회 할 수 있기 때문에 인증을 위해 입력
     */
    @GetMapping(TOKEN_URL)
    public Mono<ResponseEntity<ResponseDTO<SprinkleInfoDTO>>> sprinkleGet(@PathVariable("token") String token, @RequestHeader(value = SprinkleConst.X_USER_ID, required = false) String userId) {
        ResponseDTO<SprinkleInfoDTO> responseDto = new ResponseDTO<>();
        if (StringUtils.isEmpty(userId)) {
            responseDto.setErrMsg(REQUEST_HEADER_INVALID);
            return Mono.just(ResponseEntity.badRequest().body(responseDto));
        } else {
            return Mono.defer(() -> {
                try {
                    SprinkleInfoDTO sprinkleInfo = sprinkleService.getSprinkleInfo(token, userId);
                    responseDto.setData(sprinkleInfo);
                    responseDto.setDataCnt(1);
                    return Mono.just(ResponseEntity.ok(responseDto));
                } catch (SprinkleException e) {
                    responseDto.setErrMsg(e.getMessage());
                    return Mono.just(ResponseEntity.badRequest().body(responseDto));
                }
            }).subscribeOn(Schedulers.elastic());
        }
    }
}