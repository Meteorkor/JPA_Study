package com.meteor.sprinkle.dto;

import lombok.Data;

@Data
public class ResponseDTO<T> {
    private String errMsg;
    private T data;
    private long dataCnt = 0;
}