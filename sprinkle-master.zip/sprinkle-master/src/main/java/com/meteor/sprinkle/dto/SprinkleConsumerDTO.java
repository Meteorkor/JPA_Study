package com.meteor.sprinkle.dto;

import lombok.Data;

import java.util.Date;

@Data
public class SprinkleConsumerDTO {
    private Date consumeDate;
    private String userId;
    private long money;
}