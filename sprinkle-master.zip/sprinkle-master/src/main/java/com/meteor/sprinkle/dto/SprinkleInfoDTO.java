package com.meteor.sprinkle.dto;

import com.meteor.sprinkle.entity.status.SprinkleSubmitStatus;
import lombok.Data;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

@Data
public class SprinkleInfoDTO {
    private Date registDate;
    private long sprinkleMoney;
    private long sprinkleCompleMoney;
    private long sprinkleLeftMan;
    private long sprinkleMan;
    private SprinkleSubmitStatus submitStatus;
    private List<SprinkleConsumerDTO> sprinkleConsumerList = new ArrayList<>();
}