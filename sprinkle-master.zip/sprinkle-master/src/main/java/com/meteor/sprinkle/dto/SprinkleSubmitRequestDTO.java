package com.meteor.sprinkle.dto;

import lombok.Data;
import org.springframework.web.bind.annotation.RequestBody;

@Data
public class SprinkleSubmitRequestDTO {
    private long sprinkleMoney;
    private int sprinkleManCnt;
}