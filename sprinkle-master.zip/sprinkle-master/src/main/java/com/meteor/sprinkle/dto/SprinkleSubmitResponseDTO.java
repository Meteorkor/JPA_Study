package com.meteor.sprinkle.dto;

import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.Column;

@Data
public class SprinkleSubmitResponseDTO {
    private String token;
    private String roomId;
    private String userId;
}