package com.meteor.sprinkle.entity;

import com.meteor.sprinkle.entity.id.SprinkleDivideId;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import javax.persistence.*;
import java.util.Date;

/**
 * 뿌리기 나눈 리스트
 */
@Getter
@Setter
@EqualsAndHashCode
@Entity
@Table(name = "sprinkle_divide")
@IdClass(SprinkleDivideId.class)
@ToString
public class SprinkleDivide {
    @Id
    @Column(name = "token", length = 3)
    private String token;
    @Id
    @Column(name = "seq")
    private int seq;
    @Column(name = "consume_user_id")
    private String consumeUserId;
    @Column(name = "s_money")
    private long sprinkleMoney;
    @Column(name = "isDone")
    private boolean isDone;
    @Column(name = "consumer_date")
    private Date consumerDate;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumns(value = {
            @JoinColumn(name = "token", insertable = false, updatable = false)
    }, foreignKey = @ForeignKey(value = ConstraintMode.NO_CONSTRAINT))
    private SprinkleSubmit sprinkleSubmit;

    public void setSprinkleSubmit(SprinkleSubmit sprinkleSubmit){
        sprinkleSubmit.getSprinkleDivideList().add(this);
        this.sprinkleSubmit = sprinkleSubmit;
    }
}