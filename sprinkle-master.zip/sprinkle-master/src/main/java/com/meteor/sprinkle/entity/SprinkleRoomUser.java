package com.meteor.sprinkle.entity;

import com.meteor.sprinkle.entity.id.SprinkleRoomUserId;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.Table;

@Getter
@Setter
@EqualsAndHashCode
@Entity
@IdClass(SprinkleRoomUserId.class)
@Table(name = "sprinkle_room_user")
public class SprinkleRoomUser {
    @Id
    @Column(name = "user_id")
    private String userId;
    @Id
    @Column(name = "room_id")
    private String roomId;
}