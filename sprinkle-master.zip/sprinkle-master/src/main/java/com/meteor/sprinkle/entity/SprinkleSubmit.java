package com.meteor.sprinkle.entity;

import com.meteor.sprinkle.entity.status.SprinkleSubmitStatus;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * 뿌리기 접수한 목록
 */
@Getter
@Setter
@EqualsAndHashCode
@Entity
@Table(name = "sprinkle_submit")
public class SprinkleSubmit {
    @Id
    @Column(name = "token", length = 3)
    private String token;

    @Column(name = "room_id")
    private String roomId;

    @Column(name = "user_id")
    private String ownerId;

    @Enumerated(EnumType.STRING)
    @Column(name = "status")
    private SprinkleSubmitStatus status = SprinkleSubmitStatus.INIT;
    /**
     * 전체 돈
     */
    @Column(name = "s_money")
    private long sprinkleMoney;
    /**
     * 남은 돈
     */
    @Column(name = "s_comple_money")
    private long sprinkleCompleMoney;

    @Column(name = "s_left_man")
    private int sprinkleLeftMan;
    /**
     * 나눈 사람 수
     */
    @Column(name = "s_man")
    private long sprinkleMan;

    /**
     * 등록 시간
     */
    @Column(name = "regist_date")
    private Date registDate;

    @Column(name = "expire_date")
    private Date expireDate;

    @OneToMany(fetch = FetchType.LAZY, mappedBy = "sprinkleSubmit")
    private List<SprinkleDivide> sprinkleDivideList = new ArrayList<>();
}