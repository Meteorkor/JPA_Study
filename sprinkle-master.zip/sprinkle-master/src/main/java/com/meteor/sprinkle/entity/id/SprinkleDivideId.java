package com.meteor.sprinkle.entity.id;

import lombok.Data;

import java.io.Serializable;

@Data
public class SprinkleDivideId implements Serializable {
    private String token;
    private int seq;
}