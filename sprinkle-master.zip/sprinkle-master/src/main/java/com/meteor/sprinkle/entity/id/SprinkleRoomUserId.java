package com.meteor.sprinkle.entity.id;

import lombok.Data;

import java.io.Serializable;

@Data
public class SprinkleRoomUserId implements Serializable {
    private String userId;
    private String roomId;
}