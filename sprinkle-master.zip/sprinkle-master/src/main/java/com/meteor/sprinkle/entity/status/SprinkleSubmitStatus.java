package com.meteor.sprinkle.entity.status;

public enum SprinkleSubmitStatus {
    INIT, PROCESSING, COMPLETE
}
