package com.meteor.sprinkle.exception;

public class SprinkleException extends Exception{
    public SprinkleException(String message) {
        super(message);
    }
}