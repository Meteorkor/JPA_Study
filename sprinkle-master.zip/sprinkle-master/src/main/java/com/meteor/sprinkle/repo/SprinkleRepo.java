package com.meteor.sprinkle.repo;

import com.meteor.sprinkle.entity.SprinkleSubmit;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

public interface SprinkleRepo extends JpaRepository<SprinkleSubmit, String> {
    @Query("SELECT o FROM SprinkleSubmit  o join fetch o.sprinkleDivideList where o.token=:token")
    SprinkleSubmit findSprinkleSubmitJoinDivide(String token);
}
