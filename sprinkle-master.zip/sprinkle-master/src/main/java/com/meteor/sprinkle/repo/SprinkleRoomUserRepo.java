package com.meteor.sprinkle.repo;

import com.meteor.sprinkle.entity.SprinkleRoomUser;
import com.meteor.sprinkle.entity.id.SprinkleRoomUserId;
import org.springframework.data.jpa.repository.JpaRepository;

public interface SprinkleRoomUserRepo extends JpaRepository<SprinkleRoomUser, SprinkleRoomUserId> {
    long countByRoomId(String roomId);
}
