package com.meteor.sprinkle.service;

import com.meteor.sprinkle.SprinkleConst;
import com.meteor.sprinkle.dto.SprinkleConsumerDTO;
import com.meteor.sprinkle.dto.SprinkleInfoDTO;
import com.meteor.sprinkle.entity.SprinkleDivide;
import com.meteor.sprinkle.entity.SprinkleRoomUser;
import com.meteor.sprinkle.entity.SprinkleSubmit;
import com.meteor.sprinkle.entity.id.SprinkleDivideId;
import com.meteor.sprinkle.entity.id.SprinkleRoomUserId;
import com.meteor.sprinkle.entity.status.SprinkleSubmitStatus;
import com.meteor.sprinkle.exception.SprinkleException;
import com.meteor.sprinkle.repo.SprinkleRepo;
import com.meteor.sprinkle.repo.SprinkleRoomUserRepo;
import com.meteor.sprinkle.util.SprinkleUtil;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StringUtils;

import javax.persistence.EntityManager;
import javax.persistence.LockModeType;
import java.util.Date;
import java.util.List;

@Component
@RequiredArgsConstructor
@Slf4j
public class SprinkleService {
    private final EntityManager em;
    private final SprinkleRepo sprinkleRepo;
    private final SprinkleRoomUserRepo sprinkleRoomUserRepo;

    /**
     * 해당 사용자가 방에 있는지 체크<br>
     * 자신이 뿌린건 못받음<br>
     * 10분간 유효<br>
     */
    @Transactional
    public SprinkleConsumerDTO consume(String token, String userId) throws SprinkleException {
        //남은 금액 체크 생략
        //금액 감소 처리 생략
        //user가 정말 방에 있는지 체크 해야 하지만 생략

        //select for update로 submit 얻고
        SprinkleSubmit sprinkleSubmit = em.find(SprinkleSubmit.class, token, LockModeType.PESSIMISTIC_WRITE);

        Date now = new Date();
        if (now.after(sprinkleSubmit.getExpireDate())) {
            throw new SprinkleException(SprinkleConst.SPRINKLE_EXPIRED_DATE_ERROR);
        }
        SprinkleRoomUserId sprinkleRoomUserId = new SprinkleRoomUserId();
        sprinkleRoomUserId.setUserId(userId);
        sprinkleRoomUserId.setRoomId(sprinkleSubmit.getRoomId());

        if (sprinkleSubmit.getSprinkleLeftMan() > 0) {
            if (sprinkleSubmit.getOwnerId().equals(userId)) {//본인이 뿌린건 못받음
                throw new SprinkleException(SprinkleConst.SPRINKLE_OWNER_CONSUME_FAIL);
            }
            //방에 속한 사용자인지 체크
            if (em.find(SprinkleRoomUser.class, sprinkleRoomUserId) == null) {
                throw new SprinkleException(SprinkleConst.SPRINKLE_INVALID_MATCH);
            }
            SprinkleSubmit sprinkleSubmitJoinDivide = sprinkleRepo.findSprinkleSubmitJoinDivide(token);
            SprinkleConsumerDTO sprinkleConsumerDTO = new SprinkleConsumerDTO();
            SprinkleDivideId sprinkleDivideId = new SprinkleDivideId();
            sprinkleDivideId.setToken(token);
            int leftMan = sprinkleSubmit.getSprinkleLeftMan() - 1;
            sprinkleSubmit.setSprinkleLeftMan(leftMan);
            if (leftMan == 0) {
                sprinkleSubmit.setStatus(SprinkleSubmitStatus.COMPLETE);
            } else {
                sprinkleSubmit.setStatus(SprinkleSubmitStatus.PROCESSING);
            }
            sprinkleDivideId.setSeq(sprinkleSubmit.getSprinkleLeftMan());

            SprinkleDivide chooseDivide = null;
            boolean dupleConsume = false;
            for (SprinkleDivide sprinkleDivide : sprinkleSubmitJoinDivide.getSprinkleDivideList()) {
                if (userId.equals(sprinkleDivide.getConsumeUserId())) {
                    //한사람 한번만
                    dupleConsume = true;
                }
                if (sprinkleDivideId.getSeq() == sprinkleDivide.getSeq()) {
                    chooseDivide = sprinkleDivide;
                }
            }
            if (dupleConsume) {
                throw new SprinkleException(SprinkleConst.SPRINKLE_DUPLE_CONSUME_FAIL);
            }
            if (chooseDivide == null) {
                throw new UnknownError();
            }

            Date consumeDate = new Date();
            //SprinkleDivide sprinkleDivide = em.find(SprinkleDivide.class, sprinkleDivideId);
            chooseDivide.setConsumeUserId(userId);
            chooseDivide.setConsumerDate(consumeDate);
            sprinkleSubmit.setSprinkleCompleMoney(sprinkleSubmit.getSprinkleCompleMoney() + chooseDivide.getSprinkleMoney());
            sprinkleConsumerDTO.setConsumeDate(consumeDate);
            sprinkleConsumerDTO.setMoney(chooseDivide.getSprinkleMoney());
            sprinkleConsumerDTO.setUserId(userId);
            em.persist(chooseDivide);
            return sprinkleConsumerDTO;
        } else {//남은 뿌리기가 없습니다.
            throw new SprinkleException(SprinkleConst.SPRINKLE_EMPTY_ERROR);
        }
    }

    @Transactional
    public String createSprinkle(String userId, String roomId, long sprinkleMoney, int sprinkleManCnt) throws SprinkleException {
        final int retryCnt = 10;
        SprinkleRoomUserId sprinkleRoomUserId = new SprinkleRoomUserId();
        sprinkleRoomUserId.setRoomId(roomId);
        sprinkleRoomUserId.setUserId(userId);
        if (!sprinkleRoomUserRepo.findById(sprinkleRoomUserId).isPresent()) {
            throw new SprinkleException(SprinkleConst.SPRINKLE_INVALID_MATCH);
        }
        if (sprinkleRoomUserRepo.countByRoomId(roomId) < 3) {
            throw new SprinkleException(SprinkleConst.SPRINKLE_ROOM_NEED_3MORE);
        }


        for (int nowRetry = 0; nowRetry < retryCnt; nowRetry++) {
            String tokenId = SprinkleUtil.INSTANCE.genRandomTokenId(3);
            SprinkleSubmit sprinkleSubmit = new SprinkleSubmit();
            sprinkleSubmit.setToken(tokenId);
            sprinkleSubmit.setRoomId(roomId);
            sprinkleSubmit.setOwnerId(userId);
            sprinkleSubmit.setSprinkleMoney(sprinkleMoney);
            sprinkleSubmit.setSprinkleLeftMan(sprinkleManCnt);
            sprinkleSubmit.setSprinkleMan(sprinkleManCnt);
            Date registDate = new Date();
            sprinkleSubmit.setRegistDate(registDate);
            sprinkleSubmit.setExpireDate(SprinkleUtil.INSTANCE.createConsumeExpiredTime(registDate));
            try {
                em.persist(sprinkleSubmit);
                em.flush();
                List<Long> moneyList = SprinkleUtil.INSTANCE.calcMoney(sprinkleMoney, sprinkleManCnt);

                for (int j = 0; j < sprinkleManCnt; j++) {
                    SprinkleDivide sprinkleDivide = new SprinkleDivide();
                    sprinkleDivide.setSprinkleSubmit(sprinkleSubmit);
                    sprinkleDivide.setToken(tokenId);
                    sprinkleDivide.setSeq(j);
//                    sprinkleDivide.setConsumeUserId();
                    sprinkleDivide.setSprinkleMoney(moneyList.get(j));
                    em.persist(sprinkleDivide);
                }
                return tokenId;
            } catch (Throwable t) {
                log.error("token duple error, regen token", t);
            }
        }
        throw new SprinkleException(SprinkleConst.SPRINKLE_TOKEN_ID_GEN_FAIL);
    }

    public SprinkleInfoDTO getSprinkleInfo(String token, String userId) throws SprinkleException {
        SprinkleSubmit sprinkleSubmitJoinDivide = sprinkleRepo.findSprinkleSubmitJoinDivide(token);
        if (sprinkleSubmitJoinDivide == null || !sprinkleSubmitJoinDivide.getOwnerId().equals(userId)) {
            throw new SprinkleException(SprinkleConst.SPRINKLE_INVALID_MATCH);
        }
        Date now = new Date();
        Date infoExipredDate = SprinkleUtil.INSTANCE.createInfoExpiredTime(sprinkleSubmitJoinDivide.getRegistDate());
        if (infoExipredDate.before(now)) {
            throw new SprinkleException(SprinkleConst.SPRINKLE_INFO_EXPIRED_DATE_ERROR);
        }
        SprinkleInfoDTO dto = new SprinkleInfoDTO();
        dto.setRegistDate(sprinkleSubmitJoinDivide.getRegistDate());
        dto.setSprinkleMoney(sprinkleSubmitJoinDivide.getSprinkleMoney());
        dto.setSprinkleCompleMoney(sprinkleSubmitJoinDivide.getSprinkleCompleMoney());
        dto.setSprinkleLeftMan(sprinkleSubmitJoinDivide.getSprinkleLeftMan());
        dto.setSprinkleMan(sprinkleSubmitJoinDivide.getSprinkleMan());
        dto.setSubmitStatus(sprinkleSubmitJoinDivide.getStatus());

        for (SprinkleDivide sprinkleDivide : sprinkleSubmitJoinDivide.getSprinkleDivideList()) {
            if (!StringUtils.isEmpty(sprinkleDivide.getConsumeUserId())) {
                SprinkleConsumerDTO sprinkleConsumerDTO = new SprinkleConsumerDTO();
                sprinkleConsumerDTO.setConsumeDate(sprinkleDivide.getConsumerDate());
                sprinkleConsumerDTO.setMoney(sprinkleDivide.getSprinkleMoney());
                sprinkleConsumerDTO.setUserId(sprinkleDivide.getConsumeUserId());
                dto.getSprinkleConsumerList().add(sprinkleConsumerDTO);
            }
        }
        return dto;
    }

    @Transactional
    public void registUser(String userId, String roomId) {
        SprinkleRoomUser roomUser = new SprinkleRoomUser();
        roomUser.setRoomId(roomId);
        roomUser.setUserId(userId);
        em.persist(roomUser);
    }
}