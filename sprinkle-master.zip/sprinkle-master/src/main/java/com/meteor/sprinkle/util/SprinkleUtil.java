package com.meteor.sprinkle.util;

import lombok.Data;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.concurrent.ThreadLocalRandom;

@Data
public class SprinkleUtil {
    public final static SprinkleUtil INSTANCE = new SprinkleUtil();

    /**
     * 입력받은 money를 manCnt 만큼 나눠 List에 담는다.
     */
    public List<Long> calcMoney(long money, int leftManCnt) {
        List<Long> moneyList = new ArrayList<>();
        long leftMoney = money;
        for (int i = leftManCnt; i > 1; i--) {
            long pickMoney = ThreadLocalRandom.current().nextLong(0,leftMoney/i);
            leftMoney -= pickMoney;
            moneyList.add(pickMoney);
        }
        moneyList.add(leftMoney);
        return moneyList;
    }

    /**
     * wordCnt 만큼의 랜덤 문자열 생성
     */
    public String genRandomTokenId(int wordCnt) {
        StringBuilder stb = new StringBuilder();
        ThreadLocalRandom random = ThreadLocalRandom.current();
        for (int i = 0; i < wordCnt; i++) {
            int nn = random.nextInt(3);
            switch (nn) {
                case 0:
                    // a-z
                    stb.append((char) (random.nextInt(26) + 97));
                    break;
                case 1:
                    // A-Z
                    stb.append((char) (random.nextInt(26) + 65));
                    break;
                case 2:
                    // 0-9
                    stb.append((random.nextInt(10)));
                    break;
            }
        }
        return stb.toString();
    }

    /**
     * 현재는 입력받은 date의 10분 후를 반환
     * 만료 일자에 활용 메소드
     */
    public Date createConsumeExpiredTime(Date date) {
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(date);
        calendar.set(Calendar.MINUTE, calendar.get(Calendar.MINUTE) + 10);
        return calendar.getTime();
    }

    /**
     * 뿌린건에 대한 조회는 7일 동안
     */
    public Date createInfoExpiredTime(Date registDate) {
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(registDate);
        calendar.set(Calendar.DAY_OF_MONTH, calendar.get(Calendar.DAY_OF_MONTH) + 7);
        return calendar.getTime();
    }
}