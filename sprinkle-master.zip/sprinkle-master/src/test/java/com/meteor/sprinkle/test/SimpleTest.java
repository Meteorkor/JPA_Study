package com.meteor.sprinkle.test;

import com.meteor.sprinkle.util.SprinkleUtil;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.util.Date;
import java.util.List;
import java.util.concurrent.ThreadLocalRandom;

public class SimpleTest {

    @Test
    @DisplayName("뿌리기 돈분배가 정상적으로 수행되는지")
    void calcMoneyTest() {
        final int LEFT_MAN_CNT = ThreadLocalRandom.current().nextInt(3, 10);
        final long MONEY = ThreadLocalRandom.current().nextLong(LEFT_MAN_CNT, LEFT_MAN_CNT * 100);

        List<Long> moneyList = SprinkleUtil.INSTANCE.calcMoney(MONEY, LEFT_MAN_CNT);
        System.out.println("moneyList : " + moneyList);
        Assertions.assertEquals(LEFT_MAN_CNT, moneyList.size());
        Assertions.assertEquals(MONEY, moneyList.stream().reduce(Long::sum).get());
    }


    @Test
    void expiredTime() {
        Date now = new Date();
        Date infoExipredDate = SprinkleUtil.INSTANCE.createInfoExpiredTime(now);
        if(infoExipredDate.before(now)){
            Assertions.fail();
        }else{
            System.out.println("now : " + now);
            System.out.println("infoExipredDate : " + infoExipredDate);
        }
    }
}