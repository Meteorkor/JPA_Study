package com.meteor.sprinkle.test;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.meteor.sprinkle.service.SprinkleService;
import com.meteor.sprinkle.util.SprinkleCallTestUtil;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInstance;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.web.server.LocalServerPort;
import org.springframework.web.client.HttpClientErrorException;

import java.util.Map;

import static com.meteor.sprinkle.SprinkleConst.REQUEST_HEADER_INVALID;

@TestInstance(TestInstance.Lifecycle.PER_CLASS)
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
class SprinkleCommonErrorTest {
    @Autowired
    private SprinkleService sprinkleService;
    public static final String HTTP_LOCALHOST = "http://localhost";
    public static final String ROOM_1 = "ROOM1";
    public static final String USER_1 = "USER_1";

    @LocalServerPort
    private int port;

    @Test
    @DisplayName("조회_헤더_미설정_에러_테스트")
    public void header_setting_error() throws JsonProcessingException {
        String userId = "kim";
        long money = 1000;
        int manCnt = 5;
        try {
            SprinkleCallTestUtil.INSTANCE.submitSprinkle(HTTP_LOCALHOST, port, "", userId, money, manCnt);
            Assertions.fail("fail Test");
        } catch (HttpClientErrorException httpClientErrorException) {
            ObjectMapper objectMapper = new ObjectMapper();
            Map<String, String> map = objectMapper.readValue(httpClientErrorException.getResponseBodyAsString(), Map.class);
            Assertions.assertEquals(map.get("errMsg"), REQUEST_HEADER_INVALID);
        }
        try {
            SprinkleCallTestUtil.INSTANCE.submitSprinkle(HTTP_LOCALHOST, port, ROOM_1, "", money, manCnt);
            Assertions.fail("fail Test");
        } catch (HttpClientErrorException httpClientErrorException) {
            ObjectMapper objectMapper = new ObjectMapper();
            Map<String, String> map = objectMapper.readValue(httpClientErrorException.getResponseBodyAsString(), Map.class);
            Assertions.assertEquals(map.get("errMsg"), REQUEST_HEADER_INVALID);
        }
        try {
            SprinkleCallTestUtil.INSTANCE.submitSprinkle(HTTP_LOCALHOST, port, "", "", money, manCnt);
            Assertions.fail("fail Test");
        } catch (HttpClientErrorException httpClientErrorException) {
            ObjectMapper objectMapper = new ObjectMapper();
            Map<String, String> map = objectMapper.readValue(httpClientErrorException.getResponseBodyAsString(), Map.class);
            Assertions.assertEquals(map.get("errMsg"), REQUEST_HEADER_INVALID);
        }
    }
}