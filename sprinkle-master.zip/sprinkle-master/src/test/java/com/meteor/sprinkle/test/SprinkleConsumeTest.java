package com.meteor.sprinkle.test;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.meteor.sprinkle.SprinkleConst;
import com.meteor.sprinkle.dto.ResponseDTO;
import com.meteor.sprinkle.dto.SprinkleConsumerDTO;
import com.meteor.sprinkle.dto.SprinkleInfoDTO;
import com.meteor.sprinkle.entity.status.SprinkleSubmitStatus;
import com.meteor.sprinkle.service.SprinkleService;
import com.meteor.sprinkle.util.SprinkleCallTestUtil;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInstance;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.web.server.LocalServerPort;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.RestTemplate;

import java.util.concurrent.CountDownLatch;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

@TestInstance(TestInstance.Lifecycle.PER_CLASS)
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
public class SprinkleConsumeTest {
    public static final String HTTP_LOCALHOST = "http://localhost";
    public static final String ROOM_1 = "ROOM1";
    public static final String SUBMIT_USER_1 = "USER1";
    public static final String CONSUMER_ID = "consumerUser";
    private final RestTemplate restTemplate = new RestTemplate();
    private final long MONEY = 1000;
    private final int MAN_CNT = 5;

    @Autowired
    private SprinkleService sprinkleService;
    @LocalServerPort
    private int port;

    @BeforeAll
    private void registRoom() {
        if (!SprinkleTestInit.isInit) {
            SprinkleTestInit.isInit = true;
            sprinkleService.registUser(SUBMIT_USER_1, ROOM_1);
            sprinkleService.registUser(CONSUMER_ID, ROOM_1);
            for (int i = 0; i < MAN_CNT; i++) {
                sprinkleService.registUser(CONSUMER_ID + "_" + i, ROOM_1);
            }
        }
    }

    @Test
    @DisplayName("뿌리기 등록 및 1소비 조회 테스트")
    public void sprinkle_submit_1consume_test() {
        String tokenId = SprinkleCallTestUtil.INSTANCE.submitSprinkle(HTTP_LOCALHOST, port, ROOM_1, SUBMIT_USER_1, MONEY, MAN_CNT);
        SprinkleConsumerDTO sprinkleConsumerDTO = SprinkleCallTestUtil.INSTANCE.consumeSprinkle(HTTP_LOCALHOST, port, CONSUMER_ID, tokenId);
        try {//조회
            SprinkleInfoDTO sprinkleInfoDTO = SprinkleCallTestUtil.INSTANCE.infoSprinkle(HTTP_LOCALHOST, port, SUBMIT_USER_1, tokenId);
            Assertions.assertEquals(MAN_CNT, sprinkleInfoDTO.getSprinkleMan());
            Assertions.assertEquals(MONEY, sprinkleInfoDTO.getSprinkleMoney());
            Assertions.assertEquals(SprinkleSubmitStatus.PROCESSING, sprinkleInfoDTO.getSubmitStatus());
            Assertions.assertEquals(1, sprinkleInfoDTO.getSprinkleConsumerList().size());
            Assertions.assertNotEquals(0, sprinkleInfoDTO.getSprinkleCompleMoney());
        } catch (HttpClientErrorException httpClientErrorException) {
            Assertions.fail();
            httpClientErrorException.printStackTrace();
        }
    }

    @Test
    @DisplayName("뿌리기 등록 및 소비 소비 중복 에러 테스트")
    public void sprinkle_submit_consume_consume_duple_test() throws JsonProcessingException {
        String tokenId = SprinkleCallTestUtil.INSTANCE.submitSprinkle(HTTP_LOCALHOST, port, ROOM_1, SUBMIT_USER_1, MONEY, MAN_CNT);
        SprinkleConsumerDTO sprinkleConsumerDTO = SprinkleCallTestUtil.INSTANCE.consumeSprinkle(HTTP_LOCALHOST, port, CONSUMER_ID, tokenId);

        try {
            SprinkleCallTestUtil.INSTANCE.consumeSprinkle(HTTP_LOCALHOST, port, CONSUMER_ID, tokenId);
            Assertions.fail();
        } catch (HttpClientErrorException httpClientErrorException) {
            ObjectMapper objectMapper = new ObjectMapper();
            ResponseDTO responseDTO = objectMapper.readValue(httpClientErrorException.getResponseBodyAsString(), ResponseDTO.class);
            Assertions.assertEquals(SprinkleConst.SPRINKLE_DUPLE_CONSUME_FAIL, responseDTO.getErrMsg());
        }
    }


    @Test
    @DisplayName("뿌리기 등록 및 all 소비 조회 테스트")
    public void sprinkle_submit_all_consume_test() {
        String tokenId = SprinkleCallTestUtil.INSTANCE.submitSprinkle(HTTP_LOCALHOST, port, ROOM_1, SUBMIT_USER_1, MONEY, MAN_CNT);
        for (int i = 0; i < MAN_CNT; i++) {
            SprinkleConsumerDTO sprinkleConsumerDTO = SprinkleCallTestUtil.INSTANCE.consumeSprinkle(HTTP_LOCALHOST, port, CONSUMER_ID + "_" + i, tokenId);
        }
        try {//조회
            SprinkleInfoDTO sprinkleInfoDTO = SprinkleCallTestUtil.INSTANCE.infoSprinkle(HTTP_LOCALHOST, port, SUBMIT_USER_1, tokenId);
            System.out.println("SprinkleInfoDTO : " + sprinkleInfoDTO);
            Assertions.assertEquals(MAN_CNT, sprinkleInfoDTO.getSprinkleMan());
            Assertions.assertEquals(MONEY, sprinkleInfoDTO.getSprinkleMoney());
            Assertions.assertEquals(MAN_CNT, sprinkleInfoDTO.getSprinkleConsumerList().size());
            Assertions.assertEquals(SprinkleSubmitStatus.COMPLETE, sprinkleInfoDTO.getSubmitStatus());
            Assertions.assertNotEquals(0, sprinkleInfoDTO.getSprinkleCompleMoney());
        } catch (HttpClientErrorException httpClientErrorException) {
            Assertions.fail();
        }
    }


    @Test
    @DisplayName("뿌리기 등록 및 동시성 소비 조회 테스트")
    public void sprinkle_submit_thread_all_consume_test() {
        String tokenId = SprinkleCallTestUtil.INSTANCE.submitSprinkle(HTTP_LOCALHOST, port, ROOM_1, SUBMIT_USER_1, MONEY, MAN_CNT);
        ExecutorService executorService = Executors.newFixedThreadPool(MAN_CNT);

        CountDownLatch startCountDownLatch = new CountDownLatch(MAN_CNT + 1);
        CountDownLatch doneLatch = new CountDownLatch(MAN_CNT);

        for (int i = 0; i < MAN_CNT; i++) {
            int finalI = i;
            executorService.submit(() -> {
                startCountDownLatch.countDown();
                try {
                    startCountDownLatch.await();
                } catch (InterruptedException ignore) {
                }
                SprinkleConsumerDTO sprinkleConsumerDTO = SprinkleCallTestUtil.INSTANCE.consumeSprinkle(HTTP_LOCALHOST, port, CONSUMER_ID + "_" + finalI, tokenId);
                doneLatch.countDown();
            });
        }
        startCountDownLatch.countDown();
        try {
            startCountDownLatch.await();
            doneLatch.await();
        } catch (InterruptedException ignore) {
        }

        try {//조회
            SprinkleInfoDTO sprinkleInfoDTO = SprinkleCallTestUtil.INSTANCE.infoSprinkle(HTTP_LOCALHOST, port, SUBMIT_USER_1, tokenId);
            System.out.println("SprinkleInfoDTO : " + sprinkleInfoDTO);
            Assertions.assertEquals(MAN_CNT, sprinkleInfoDTO.getSprinkleMan());
            Assertions.assertEquals(MONEY, sprinkleInfoDTO.getSprinkleMoney());
            Assertions.assertEquals(MAN_CNT, sprinkleInfoDTO.getSprinkleConsumerList().size());
            Assertions.assertEquals(SprinkleSubmitStatus.COMPLETE, sprinkleInfoDTO.getSubmitStatus());
            Assertions.assertNotEquals(0, sprinkleInfoDTO.getSprinkleCompleMoney());
        } catch (HttpClientErrorException httpClientErrorException) {
            Assertions.fail();
        }
    }

    @Test
    @DisplayName("뿌리기 등록 및 초과 소비 테스트")
    public void sprinkle_submit_exceed_consume_test() throws JsonProcessingException {
        String tokenId = SprinkleCallTestUtil.INSTANCE.submitSprinkle(HTTP_LOCALHOST, port, ROOM_1, SUBMIT_USER_1, MONEY, MAN_CNT);
        try {
            for (int i = 0; i < MAN_CNT + 1; i++) {
                SprinkleConsumerDTO sprinkleConsumerDTO = SprinkleCallTestUtil.INSTANCE.consumeSprinkle(HTTP_LOCALHOST, port, CONSUMER_ID + "_" + i, tokenId);
            }
            Assertions.fail("테스트 실패");
        } catch (HttpClientErrorException httpClientErrorException) {
            ObjectMapper objectMapper = new ObjectMapper();
            ResponseDTO responseDTO = objectMapper.readValue(httpClientErrorException.getResponseBodyAsString(), ResponseDTO.class);
            Assertions.assertEquals(SprinkleConst.SPRINKLE_EMPTY_ERROR, responseDTO.getErrMsg());
        }
    }

    @Test
    @DisplayName("뿌리기 등록 및 본인 소비 에러 테스트")
    public void sprinkle_submit_host_consume_test() throws JsonProcessingException {
        String tokenId = SprinkleCallTestUtil.INSTANCE.submitSprinkle(HTTP_LOCALHOST, port, ROOM_1, SUBMIT_USER_1, MONEY, MAN_CNT);
        try {//consume
            SprinkleCallTestUtil.INSTANCE.consumeSprinkle(HTTP_LOCALHOST, port, SUBMIT_USER_1, tokenId);
            Assertions.fail("본인 소비로 에러가 발생해야함");
        } catch (HttpClientErrorException httpClientErrorException) {
            ObjectMapper objectMapper = new ObjectMapper();
            ResponseDTO responseDTO = objectMapper.readValue(httpClientErrorException.getResponseBodyAsString(), ResponseDTO.class);
            Assertions.assertEquals(SprinkleConst.SPRINKLE_OWNER_CONSUME_FAIL, responseDTO.getErrMsg());
        }
    }
}