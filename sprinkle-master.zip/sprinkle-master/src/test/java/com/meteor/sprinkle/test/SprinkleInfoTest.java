package com.meteor.sprinkle.test;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.meteor.sprinkle.SprinkleConst;
import com.meteor.sprinkle.dto.ResponseDTO;
import com.meteor.sprinkle.dto.SprinkleInfoDTO;
import com.meteor.sprinkle.entity.status.SprinkleSubmitStatus;
import com.meteor.sprinkle.service.SprinkleService;
import com.meteor.sprinkle.util.SprinkleCallTestUtil;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInstance;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.web.server.LocalServerPort;
import org.springframework.web.client.HttpClientErrorException;

import java.util.UUID;
import java.util.concurrent.ThreadLocalRandom;
@TestInstance(TestInstance.Lifecycle.PER_CLASS)
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
public class SprinkleInfoTest {
    public static final String HTTP_LOCALHOST = "http://localhost";

    public static final String ROOM_1 = "ROOM1";
    public static final String SUBMIT_USER_1 = "USER1";
    public static final String CONSUMER_ID = "consumerUser";
    private final long MONEY = 1000;
    private final int MAN_CNT = 5;


    @Autowired
    private SprinkleService sprinkleService;
    @LocalServerPort
    private int port;

    @BeforeAll
    public void registRoom(){
        if(!SprinkleTestInit.isInit){
            SprinkleTestInit.isInit = true;
            sprinkleService.registUser(SUBMIT_USER_1, ROOM_1);
            sprinkleService.registUser(CONSUMER_ID, ROOM_1);
            for (int i = 0; i < MAN_CNT; i++) {
                sprinkleService.registUser(CONSUMER_ID + "_" + i, ROOM_1);
            }
        }
    }
    @Test
    @DisplayName("뿌리기 등록 조회")
    public void sprinkle_submit_info_test() {
        final int MAN_CNT = ThreadLocalRandom.current().nextInt(3, 11);
        final long MONEY = ThreadLocalRandom.current().nextLong(MAN_CNT, MAN_CNT * 100);

        String tokenId = SprinkleCallTestUtil.INSTANCE.submitSprinkle(HTTP_LOCALHOST, port, ROOM_1, SUBMIT_USER_1, MONEY, MAN_CNT);

        SprinkleInfoDTO sprinkleInfoDTO = SprinkleCallTestUtil.INSTANCE.infoSprinkle(HTTP_LOCALHOST, port, SUBMIT_USER_1, tokenId);
        Assertions.assertEquals(MAN_CNT, sprinkleInfoDTO.getSprinkleMan());
        Assertions.assertEquals(MONEY, sprinkleInfoDTO.getSprinkleMoney());
        Assertions.assertEquals(SprinkleSubmitStatus.INIT, sprinkleInfoDTO.getSubmitStatus());
        Assertions.assertEquals(0, sprinkleInfoDTO.getSprinkleCompleMoney());
        Assertions.assertEquals(0, sprinkleInfoDTO.getSprinkleConsumerList().size());
    }

    @Test
    @DisplayName("뿌리기 하지 않고 조회, 잘못된 tokenId로 조회, 에러테스트")
    public void sprinkle_wrong_info_test() throws JsonProcessingException {
        String tokenId = UUID.randomUUID().toString();
        try{
            SprinkleInfoDTO sprinkleInfoDTO = SprinkleCallTestUtil.INSTANCE.infoSprinkle(HTTP_LOCALHOST, port, SUBMIT_USER_1, tokenId);
            Assertions.fail("테스트 실패");
        }catch (HttpClientErrorException httpClientErrorException){
            ObjectMapper objectMapper = new ObjectMapper();
            ResponseDTO responseDTO = objectMapper.readValue(httpClientErrorException.getResponseBodyAsString(), ResponseDTO.class);
            Assertions.assertEquals(SprinkleConst.SPRINKLE_INVALID_MATCH, responseDTO.getErrMsg());
        }
    }


    @Test
    @DisplayName("뿌리기 등록 다른 사용자 조회 에러 테스트")
    public void sprinkle_submit_info_other_get_test() throws JsonProcessingException {
        final int MAN_CNT = ThreadLocalRandom.current().nextInt(3, 11);
        final long MONEY = ThreadLocalRandom.current().nextLong(MAN_CNT, MAN_CNT * 100);

        String tokenId = SprinkleCallTestUtil.INSTANCE.submitSprinkle(HTTP_LOCALHOST, port, ROOM_1, SUBMIT_USER_1, MONEY, MAN_CNT);

        try{
            SprinkleInfoDTO sprinkleInfoDTO = SprinkleCallTestUtil.INSTANCE.infoSprinkle(HTTP_LOCALHOST, port, CONSUMER_ID, tokenId);
            Assertions.fail("테스트 실패");
        }catch (HttpClientErrorException httpClientErrorException){
            ObjectMapper objectMapper = new ObjectMapper();
            ResponseDTO responseDTO = objectMapper.readValue(httpClientErrorException.getResponseBodyAsString(), ResponseDTO.class);
            Assertions.assertEquals(SprinkleConst.SPRINKLE_INVALID_MATCH, responseDTO.getErrMsg());
        }
    }
}