package com.meteor.sprinkle.test;

/**
 * mvn test 초기화 로직이 여러번 실행됨을 방지
 */
public class SprinkleTestInit {
    public static boolean isInit = false;
}