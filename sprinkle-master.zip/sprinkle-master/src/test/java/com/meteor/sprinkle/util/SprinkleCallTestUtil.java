package com.meteor.sprinkle.util;

import com.meteor.sprinkle.SprinkleConst;
import com.meteor.sprinkle.dto.ResponseDTO;
import com.meteor.sprinkle.dto.SprinkleConsumerDTO;
import com.meteor.sprinkle.dto.SprinkleInfoDTO;
import com.meteor.sprinkle.dto.SprinkleSubmitRequestDTO;
import com.meteor.sprinkle.dto.SprinkleSubmitResponseDTO;
import lombok.Data;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;

import java.util.Objects;

import static com.meteor.sprinkle.SprinkleConst.X_ROOM_ID;
import static com.meteor.sprinkle.SprinkleConst.X_USER_ID;


@Data
public class SprinkleCallTestUtil {
    public static final SprinkleCallTestUtil INSTANCE = new SprinkleCallTestUtil();


    public String submitSprinkle(String addr, int port, String roomId, String userId, long money, int manCnt) {
        RestTemplate restTemplate = new RestTemplate();
        HttpHeaders headers = new HttpHeaders();
        headers.set(X_ROOM_ID, roomId);
        headers.set(X_USER_ID, userId);
        SprinkleSubmitRequestDTO sprinkleSubmitRequestDTO = new SprinkleSubmitRequestDTO();
        sprinkleSubmitRequestDTO.setSprinkleManCnt(manCnt);
        sprinkleSubmitRequestDTO.setSprinkleMoney(money);
        HttpEntity<SprinkleSubmitRequestDTO> httpEntity = new HttpEntity<>(sprinkleSubmitRequestDTO, headers);

        String submitUrl = addr + ":" + port + "/" + SprinkleConst.sprinkle_CONST;

        ParameterizedTypeReference<ResponseDTO<SprinkleSubmitResponseDTO>> ref = new ParameterizedTypeReference<ResponseDTO<SprinkleSubmitResponseDTO>>() {
        };

        ResponseEntity<ResponseDTO<SprinkleSubmitResponseDTO>> stringResponseEntity = restTemplate.exchange(submitUrl, HttpMethod.POST, httpEntity, ref);
        SprinkleSubmitResponseDTO sprinkleSubmitRequestDTO1 = Objects.requireNonNull(stringResponseEntity.getBody()).getData();
        return sprinkleSubmitRequestDTO1.getToken();
    }

    public SprinkleConsumerDTO consumeSprinkle(String addr, int port,String consumerId, String tokenId) {
        RestTemplate restTemplate = new RestTemplate();
        HttpHeaders headers = new HttpHeaders();
//        headers.set(X_ROOM_ID, roomId);
        headers.set(X_USER_ID, consumerId);

        String consumeUrl = addr + ":" + port + "/" + SprinkleConst.sprinkle_CONST + "/" + tokenId;
        ParameterizedTypeReference<ResponseDTO<SprinkleConsumerDTO>> ref = new ParameterizedTypeReference<ResponseDTO<SprinkleConsumerDTO>>() {
        };
        ResponseEntity<ResponseDTO<SprinkleConsumerDTO>> stringResponseEntity = restTemplate.exchange(consumeUrl, HttpMethod.POST, new HttpEntity<>(headers), ref);
        return Objects.requireNonNull(stringResponseEntity.getBody()).getData();
    }

    public SprinkleInfoDTO infoSprinkle(String addr, int port,String createUserId, String tokenId) {
        RestTemplate restTemplate = new RestTemplate();
        String url = addr + ":" + port + "/" + SprinkleConst.sprinkle_CONST + "/" + tokenId;
        HttpHeaders headers = new HttpHeaders();
//        headers.set(X_ROOM_ID, roomId);
        headers.set(X_USER_ID, createUserId);
        ParameterizedTypeReference<ResponseDTO<SprinkleInfoDTO>> infoRef = new ParameterizedTypeReference<ResponseDTO<SprinkleInfoDTO>>() {
        };
        ResponseEntity<ResponseDTO<SprinkleInfoDTO>> infoGetResponse = restTemplate.exchange(url, HttpMethod.GET, new HttpEntity<>(headers), infoRef);
        return Objects.requireNonNull(infoGetResponse.getBody()).getData();
    }
}